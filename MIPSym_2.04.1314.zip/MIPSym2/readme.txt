MIPSym 2.04.1314

This is the Windows version of MIPSym, a simulator for the MIPS R2000/R3000 processor.

Please unzip the contents of the MIPSym_2.04.1314.zip file into your "C:\Program Files (x86)" 
directory; this should create a new directory at "C:\Program Files (x86)\MIPSym2".

You will also find a shortcut at "C:\Program Files (x86)\MIPSym2\MIPSym.exe" that 
you can use to run the simulator.

Please note that MIPSym.exe is a university research project, and it has not been signed 
by Microsoft, and Windows will warn you of this fact the first time you run it.

As of Ver 2.04, Ctrl-scroll will resize text in both the IDE and the console windows.

